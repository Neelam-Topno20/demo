package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exceptions.BankingServicesDownException;
import com.capgemini.bank.exceptions.DdAmountNotValidException;

public interface IDemandDraftService {
	int addDemandDraftDetails(DemandDraft demandDraft)throws DdAmountNotValidException,BankingServicesDownException;
	DemandDraft getDemandDraftDetails(int transactionId);
}
