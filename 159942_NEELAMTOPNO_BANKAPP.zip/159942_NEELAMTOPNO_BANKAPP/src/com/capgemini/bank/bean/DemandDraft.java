package com.capgemini.bank.bean;

import java.time.LocalDate;

public class DemandDraft {
	private int transactionId;
	private String customerName;
	private String inFavorOf;
	private long phoneNumber;
	private LocalDate dateOfTransaction;
	private double ddAmount;
	private double ddCommission;
	private String ddDescription;
	public DemandDraft() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public DemandDraft(int transactionId, String customerName,
			String inFavorOf, long phoneNumber, LocalDate dateOfTransaction,
			double ddAmount, double ddCommission, String ddDescription) {
		super();
		this.transactionId = transactionId;
		this.customerName = customerName;
		this.inFavorOf = inFavorOf;
		this.phoneNumber = phoneNumber;
		this.dateOfTransaction = dateOfTransaction;
		this.ddAmount = ddAmount;
		this.ddCommission = ddCommission;
		this.ddDescription = ddDescription;
	}

	public DemandDraft(String customerName, String inFavorOf, long phoneNumber,
			double ddAmount, String ddDescription) {
		super();
		this.customerName = customerName;
		this.inFavorOf = inFavorOf;
		this.phoneNumber = phoneNumber;
		this.ddAmount = ddAmount;
		this.ddDescription = ddDescription;
	}

	public DemandDraft(String customerName, String inFavorOf, long phoneNumber,
			LocalDate dateOfTransaction, double ddAmount, double ddCommission,
			String ddDescription) {
		super();
		this.customerName = customerName;
		this.inFavorOf = inFavorOf;
		this.phoneNumber = phoneNumber;
		this.dateOfTransaction = dateOfTransaction;
		this.ddAmount = ddAmount;
		this.ddCommission = ddCommission;
		this.ddDescription = ddDescription;
	}

	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getInFavorOf() {
		return inFavorOf;
	}
	public void setInFavorOf(String inFavorOf) {
		this.inFavorOf = inFavorOf;
	}
	public long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public LocalDate getDateOfTransaction() {
		return dateOfTransaction;
	}
	public void setDateOfTransaction(LocalDate dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}

	public double getDdAmount() {
		return ddAmount;
	}

	public void setDdAmount(double ddAmount) {
		this.ddAmount = ddAmount;
	}

	public double getDdCommission() {
		return ddCommission;
	}

	public void setDdCommission(double ddCommission) {
		this.ddCommission = ddCommission;
	}

	public String getDdDescription() {
		return ddDescription;
	}

	public void setDdDescription(String ddDescription) {
		this.ddDescription = ddDescription;
	}
	
	}
	
	

