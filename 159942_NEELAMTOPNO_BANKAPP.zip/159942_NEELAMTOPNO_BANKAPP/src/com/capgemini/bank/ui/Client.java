package com.capgemini.bank.ui;

import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exceptions.BankingServicesDownException;
import com.capgemini.bank.exceptions.DdAmountNotValidException;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;
import com.capgemini.bank.util.ConnectionProvider;

public class Client {

	public static void main(String[] args) throws DdAmountNotValidException, BankingServicesDownException {
			
		if(ConnectionProvider.getDBConnection()!=null){
			System.out.println("connection set ");
		}
		else{
			System.out.println("connection not set");
		}
		
		IDemandDraftService idemandDraftService = new DemandDraftService();
		DemandDraft demandDraft=new DemandDraft();
		
		
		
		Scanner sc=new Scanner(System.in);
		String s=null;
		
		do{
			System.out.println("1)Enter Demand Draft Details ");
			System.out.println("2)Exit");
			System.out.println("Enter Your Choice");
			int choice= sc.nextInt();
			
			switch(choice){
				case 1:
			System.out.println("Enter the name of the customer");
			String s1=sc.next();
			demandDraft.setCustomerName(s);
			System.out.println("Enter customer phone number");
			long l=sc.nextLong();
			demandDraft.setPhoneNumber(l);
			System.out.println("In Favor of");
			String s2=sc.next();
			demandDraft.setInFavorOf(s2);
			System.out.println("Enter Demand Draft amount(in Rs)");
			double d=sc.nextDouble();
			demandDraft.setDdAmount(d);
			System.out.println("Enter Remarks:");
			String s3=sc.next();
			demandDraft.setDdDescription(s3);
			int transactionId=idemandDraftService.addDemandDraftDetails(demandDraft);
			System.out.println("Your Demand Draft request has been succesfully registered along with the "+transactionId);
			
			break;
				case 2:
					break;
					
			default:
				System.out.println("Invalid Input");
			}
		System.out.println("Do you want to continue?(y/n)");
		s=sc.next();
		
		}while(s.startsWith("Y") || s.startsWith("y"));

	}

}
