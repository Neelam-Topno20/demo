package com.cg.project.threadwork;

import java.util.ArrayList;
import java.util.Collections;

import com.cg.project.beans.Employee;

public class MainClass {

	public static void main(String[] args) {
		
		//try {
		/*	RunnableResource r1=new RunnableResource();
			Thread t1=new Thread(r1, "threadname");
			t1.start();
			t1.setPriority(Thread.NORM_PRIORITY);//accepts value from 1 to 10
			t1.join(1000);
			
			MyThread th1=new MyThread("odd");
			MyThread th2=new MyThread("even");//new born
			th1.start();//eligible for runnable pool
			th2.start();
			System.out.println("main thread end");*/
			
			
			Runnable runnableResource=()->{
				for(int i=1;i<10;i++)
					System.out.println("Tick "+i);
			};
			Thread th1=new Thread();
			th1.start();
			
		/*} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		
			ArrayList< Employee> empList=new ArrayList<>();
			empList.add(new Employee(111,12000,"Kumar"));
			empList.add(new Employee(113,12000,"Kumar"));
			empList.add(new Employee(114,12000,"Kumar"));
			empList.add(new Employee(112,12000,"Kumar"));
			empList.add(new Employee(115,12000,"Kumar"));
			empList.add(new Employee(116,12000,"Kumar"));
			empList.add(new Employee(117,12000,"Numar"));
			empList.add(new Employee(118,12000,"Kumar"));
			empList.add(new Employee(119,12000,"Kumar"));
			
			Collections.sort(empList, (emp1,emp2)->emp1.getEmpId()-emp2.getEmpId());
			
			
			empList.stream()
			.distinct()
			.filter(e->e.getName().startsWith("N"))
			.forEach(employee->System.out.println(employee.toString()));
			
			long count=empList.stream()
				.distinct()
				.count();
				System.out.println(count+" "+empList.size());
					
					
					
					
					
				
			
			
			
			
			
			
			
			
			
			
			

		
	}

}
