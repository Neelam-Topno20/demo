package com.cg.project.threadwork;

public class MyThread extends Thread{

	
	public MyThread(String name) {
		super(name);
	}

	@Override
	public void run() {
		
		try {
			for(int i=0;i<=10;i++){
				if(this.getName().equals("even")){
					if(i%2==0)
						System.out.println(this.getName()+i);
					Thread.sleep(1000);
				}
				if(this.getName().equals("odd"))
					if(i%2!=0)
						System.out.println(this.getName()+i);
				Thread.sleep(1000);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
