import java.util.Arrays;
public class BinarySearch {
	BinarySearch(){}
	private void binarySearch(int array[],int low,int high,int searchitem){
		int mid;
		while(low<=high){
			mid=(low+high)/2;
			if(array[mid]==searchitem){
				System.out.println("Data found at index: "+mid);
				break;
			}
			else if(searchitem>array[mid])
				low=mid+1;
			else
				high=mid-1;
			
		}
		if(low>high)
			System.out.println("Data not found");
	}
	
	public static void main(String srgs[]){
		BinarySearch bs=new BinarySearch();
		int searchitem=45;
		int array[]={23,32,45,89,73,49,56,67};
		Arrays.sort(array);
		System.out.println("Print Original Array");
		for(int i=0;i<array.length;i++)
			System.out.print(array[i]+" ");
		System.out.println();
		System.out.println("data to search="+searchitem);
		bs.binarySearch(array,0,array.length,searchitem);
	}
}
