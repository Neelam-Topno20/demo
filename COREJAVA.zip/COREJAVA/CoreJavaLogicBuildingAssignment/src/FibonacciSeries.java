public class FibonacciSeries {

	public static void main(String[] args) {
		int a=0,b=1,count=1,n,tmp;
		n=10;tmp=b;
		System.out.print(a);
		while(count<n){
				System.out.print(b+" ");
				tmp=b;
				b=a+b;
				a=tmp;
				count++;
		}
		}
	}

