public class MainClass {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Month jan=Month.JAN;
		System.out.println(jan.getMonthIndex()+"   "+jan.getMonthName());
		Month feb=Month.FEB;
		System.out.println(feb.getMonthIndex()+"   "+feb.getMonthName());
		Month mar=Month.MAR;
		System.out.println(mar.getMonthIndex()+"   "+mar.getMonthName());
		Month apr=Month.APR;
		System.out.println(apr.getMonthIndex()+"   "+apr.getMonthName());
		Month may=Month.MAY;
		System.out.println(may.getMonthIndex()+"   "+may.getMonthName());
		Month jun=Month.JUN;
		System.out.println(jun.getMonthIndex()+"   "+jun.getMonthName());
		Month jul=Month.JUL;
		System.out.println(jul.getMonthIndex()+"   "+jul.getMonthName());
		Month aug=Month.AUG;
		System.out.println(aug.getMonthIndex()+"   "+aug.getMonthName());
		Month sep=Month.SEP;
		System.out.println(sep.getMonthIndex()+"   "+sep.getMonthName());
		Month oct=Month.OCT;
		System.out.println(oct.getMonthIndex()+"   "+oct.getMonthName());
		Month nov=Month.NOV;
		System.out.println(nov.getMonthIndex()+"   "+nov.getMonthName());
		Month dec=Month.DEC;
		System.out.println(dec.getMonthIndex()+"   "+dec.getMonthName());
		
	}

}
