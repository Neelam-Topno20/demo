
public class LinearArraySearch {
	public static void main(String []str){
		int numList[]={1,2,3,4,5,6,7,8,9,10};
		int flag=-1,searchdata=65;
		for(int i=0;i<numList.length;i++)
			if(numList[i]==searchdata){
				System.out.println("data found at index "+i);
				flag=1;
				break;			
			}				
		if(flag==-1)
			System.out.println("data not found");			
	}
}