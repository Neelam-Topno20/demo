
public class DecimalToBinary {

	private void decimalToBinary(long num){
		long binary=0;
		int placeholder=1;;
		if(num==1  ||  num ==0){
			   binary=num;
			   System.out.println(binary);
		}
		else if(num>1){
			while(num>=1){
					binary=binary+(num%2)*placeholder;
					placeholder*=10;
					num/=2;
			}
			binary=binary+(num%2)*placeholder;
			System.out.println(binary);
		}
	}
	public static void main(String[] args) {
		DecimalToBinary dtb=new DecimalToBinary();
		dtb.decimalToBinary(32);
	}

}
