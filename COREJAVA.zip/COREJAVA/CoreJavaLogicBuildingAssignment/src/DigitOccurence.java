
public class DigitOccurence {
	public static void main(String[] args) {
		int []numList={1,2,3,5,0,4,3,1,2,1};
		int []arrayCount=new int[100];
		for(int i=0;i<numList.length;i++)
			arrayCount[numList[i]]++;
		for(int i=0;i<arrayCount.length;i++)
			if(arrayCount[i]!=0)
				System.out.println("The occurrences of "+i+" is "+arrayCount[i]);
	}
}