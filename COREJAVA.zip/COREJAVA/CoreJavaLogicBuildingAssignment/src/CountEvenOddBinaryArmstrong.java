
public class CountEvenOddBinaryArmstrong {
	public static void main(String[] args) {
		int evenCount=0,oddCount=0,primeCount=0,armstrongCount=0,flag;
		int []numList={1,3,5,7,11,1,13,17,19,21,153};
		for(int i=0;i<numList.length;i++)
			if(numList[i]%2==0)
				evenCount++;
			else
				oddCount++;
		for(int i=0;i<numList.length;i++){
			flag=1;
			for(int j=2;j<numList[i];j++){
				if(numList[i]%j==0){
					flag=0;
					break;
				}
			}
			if(flag==1 && numList[i]!=1)
				primeCount++;
		}
		for(int i=0;i<numList.length;i++){
			int NewNumber=0;
			int digit;
			int number=numList[i];
			while(number!=0){
				digit=number%10;
				NewNumber=NewNumber+(digit*digit*digit);
				number=number/10;
			}
			if(numList[i]==NewNumber)
				armstrongCount++;
		}
		System.out.println("The even count is "+evenCount+" odd count is "+oddCount+" prime count is "+primeCount+" and armstrong number count is "+armstrongCount);
	}
}