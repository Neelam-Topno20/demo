public class QuickSort {
	int partition(int []numList,int startIndex,int endIndex){
		int pivot=numList[endIndex];
		int i=startIndex-1;
		for(int j=startIndex;j<=endIndex-1;j++){
			if(numList[j]<=pivot){
				i++;
				int temp=numList[i];
				numList[i]=numList[j];
				numList[j]=temp;
			}
		}
		int temp=numList[i+1];
		numList[i+1]=numList[endIndex];
		numList[endIndex]=temp;
		return i+1;
	}
	void quickSort(int []numList,int startIndex,int endIndex){
		if(startIndex<endIndex){
			int pivotIndex=partition(numList,startIndex,endIndex);
			quickSort(numList,startIndex,pivotIndex-1);
			quickSort(numList,pivotIndex+1,endIndex);
		}
	}
	public static void main(String[] args) {
	int []numList={5,7,2,4,9,10,15,13,54,22,89};
	QuickSort qsort=new QuickSort();
	qsort.quickSort(numList,0,numList.length-1);
	for(int i=0;i<numList.length;i++)
		System.out.print(numList[i]+" ");
	}
}