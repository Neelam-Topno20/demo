
public class Practice {

	
	enum Color{
		lamborghini(900),tata(2),audi(50),fiat(15),honda(12);
		private  int  index;
		  Color(int index){
			  this.index=index;  
	 }
	  
	}
	
	/*enum RED
	{ 
		int arg1;String arg0;
	    private RED(String arg0, int arg1) {
			// TODO Auto-generated constructor stub
		}
	    
	} 
	enum GREEN
	{ 
		String arg0;
		int arg1;
		private GREEN(String arg0, int arg1) {
			// TODO Auto-generated constructor stub
		}  
	} 
	enum BLUE
	{ 
		String arg0;int arg1;
	     private BLUE(String arg0, int arg1) {
				// TODO Auto-generated constructor stub
			}
		    
	} */
	  
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}
