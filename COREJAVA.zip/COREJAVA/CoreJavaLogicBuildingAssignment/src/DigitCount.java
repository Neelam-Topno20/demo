
public class DigitCount {
	public static void main(String[] args) {
		int []numList={1,2,3,11,12,1,3,14,245,356,678};
		int []arrayCount=new int[5];
		for(int i=0;i<numList.length;i++){
			int digitCount=0;
			int number=numList[i];
			while(number!=0){
				digitCount++;
				number=number/10;
			}
			arrayCount[digitCount]++;
		}
		for(int i=0;i<arrayCount.length;i++)
			if(arrayCount[i]!=0)
				System.out.println(i+" digit number count is "+arrayCount[i]);
	}
}