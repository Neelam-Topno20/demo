class PalindromeNumber{
	public static void main(String []str)
	{
		int num,rev_num=0,temp_num,placeholder=10;
		num=11211;
		temp_num=num;
		while(temp_num!=0){
			rev_num=(rev_num*placeholder)+(temp_num%10);
			temp_num/=10;	
		}
		if(rev_num==num)
			System.out.println("The number is a palindrome");
		else
			System.out.println("The number is not a palindrome");
	}
}

