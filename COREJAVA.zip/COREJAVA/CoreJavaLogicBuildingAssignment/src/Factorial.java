
public class Factorial {
	public static void main(String[] args) {
		int number=5,factorial=1,i;
		if(number>1)
			for(i=number;i>1;i--)
				factorial=factorial*i;
		System.out.println("The Factorial of "+number+" is "+factorial);
	}
}