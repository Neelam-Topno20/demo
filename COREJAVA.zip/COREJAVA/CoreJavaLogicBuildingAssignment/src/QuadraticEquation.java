
public class QuadraticEquation {
	QuadraticEquation(){}
	
	private void quadraticEquation(int a,int b,int c){
		double root1,root2;
		root1=(-b+Math.sqrt((b*b)-(4*a*c)))/(2*a);
		root2=(-b-Math.sqrt((b*b)-(4*a*c)))/(2*a);
		System.out.println("The roots for this equation are:=");
		System.out.println("root1 = "+root1+" 		root2 = "+root2);
	}
	public static void main(String []args){
		QuadraticEquation qe=new QuadraticEquation();
		qe.quadraticEquation(1,-3,2);
	}
}
