class ArmstrongNumber{
	public static void main(String []str){
		int num,temp_num;
		num=153;
		double result_num=0;
		temp_num=num;
		while(temp_num!=0){
			result_num=result_num+Math.pow(temp_num%10,3);
			temp_num/=10;
		}
		if(result_num==num)
			System.out.println(num+" is an armstrong number");
		else
			System.out.println(num+" is not an armstrong number");

	}
}