package com.cg.classwork.client;
import  com.cg.classwork.beans.*;
public class MainClass {

	public static void main(String[] args) {
		/*Address address=new Address("Pune","Maharastra","India",4012011);*/
       Customer customer=new Customer(1001,"Ashav","Kumar",new Address("Bangalore","Karnataka", "India", 5646211));
       System.out.println(customer.getCustomerId());
       System.out.println(customer.getFirstName());
       System.out.println(customer.getLastName());
       System.out.println(customer.getAddress().getCity());
       System.out.println(customer.getAddress().getPincode());
       System.out.println(customer.getAddress().getCountry());
       
      
       
      
       
      /* customer.setAddress(new Address("Bangalore","Karnataka", "India", 5646211));*/
       
       
	}

}
