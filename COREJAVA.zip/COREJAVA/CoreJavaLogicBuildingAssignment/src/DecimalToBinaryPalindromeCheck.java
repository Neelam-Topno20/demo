import java.util.Scanner;
public class DecimalToBinaryPalindromeCheck {
	public static void main(String[] args) {
		Scanner scnr=new Scanner(System.in);
		int value=scnr.nextInt();
		int i=0,storedValue=value;
		int []binaryNumber=new int[100];
		while(value!=0){
			binaryNumber[i++]=value%2;;
			value=value/2;
		}
		int startIndex=0,endIndex=i-1,flag=1;
		while(startIndex<endIndex){
			if(binaryNumber[startIndex]!=binaryNumber[endIndex]){
				flag=0;
				System.out.println("The binary conversion of "+storedValue+" is not Palindrome");
				break;
			}
			else{
				startIndex++;
				endIndex--;
			}
		}
		if(flag==1)
			System.out.println("The Binary conversion of "+storedValue+" is Palindrome");
	}
}