package com.cg.project.matservices;

import com.cg.project.exceptions.InvalidNumberRangeExceptions;

public interface MathServices {
	public abstract int addNums(int n1,int n2)throws InvalidNumberRangeExceptions;
	abstract int subNums(int n1,int n2)throws InvalidNumberRangeExceptions;
	int multiNums(int n1,int n2);
}
