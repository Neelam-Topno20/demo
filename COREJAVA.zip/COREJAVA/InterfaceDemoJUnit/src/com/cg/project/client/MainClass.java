package com.cg.project.client;

import com.cg.project.exceptions.InvalidNumberRangeExceptions;
import com.cg.project.matservices.MathServices;
import com.cg.project.matservices.MathServicesImpl;

public class MainClass {

	public static void main(String[] args) {
		
		try{
			MathServices services=new MathServicesImpl();
			
			System.out.println(services.addNums(10, 20));
			System.out.println(services.subNums(10, 20));
			System.out.println(services.multiNums(10, 20));
		}
		catch(InvalidNumberRangeExceptions e){
			e.printStackTrace();
			
			
		}
	}

}
