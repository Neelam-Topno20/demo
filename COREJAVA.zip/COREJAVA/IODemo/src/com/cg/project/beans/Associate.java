package com.cg.project.beans;

import java.io.Serializable;

public class Associate implements Serializable {
	private int associateId;
	transient private int salary;
	private String name;
	private Address address;
	private static int COUNTER=1;
	public Associate() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Associate(int associateId, int salary, String name) {
		super();
		this.associateId = associateId;
		this.salary = salary;
		this.name = name;
	}
	
	public Associate(int associateId, int salary, String name, Address address) {
		super();
		this.associateId = associateId;
		this.salary = salary;
		this.name = name;
		this.address = address;
	}
	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public int getAssociateId() {
		return associateId;
	}
	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Associate [associateId=" + associateId + ", name=" + name
				+ ", address=" + address + "]";
	}
	
	
	

}
