package com.cg.project.iodemo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class IOClassesDemo  {
	
	public static void fileClassDemo() throws IOException{
		File file=new File("d:\\DataFile.txt");
		if(!file.exists())
			file.createNewFile();
		System.out.println(file.exists());
		System.out.println(file.canWrite());
		System.out.println(file.canRead());
		System.out.println(file.length());
		System.out.println(file.getPath());
		System.out.println(file.getName());
		
	}
	
	public static void byteStreamReadWrite(File fileFrom,File fileTo) throws FileNotFoundException,IOException{
		/*FileInputStream scrStream=new FileInputStream(fileFrom);
		FileOutputStream destStream=new FileOutputStream(fileTo);*/
		try(BufferedInputStream scrStream=new BufferedInputStream(new FileInputStream(fileFrom))){//objects of classses autoclosable type 
			//classes which implement autoclosable interface
			//try with resource
			try(BufferedOutputStream destStream=new BufferedOutputStream(new FileOutputStream(fileTo))){
		//recommended streams
		/*int a=0;//returns ascii char -1 no char 
		while((a=scrStream.read())!=-1){   
		     destStream.write(a);  													1 way
			System.out.println((char)a);			
		}*/
		
		/*byte [] dataBuffer=new byte[1024];
		while (scrStream.read(dataBuffer)!=-1) {
			destStream.write(dataBuffer);						2 way
			
		}*/
		
		byte [] dataBuffer=new byte[(int)fileFrom.length()];
		scrStream.read(dataBuffer);
		destStream.write(dataBuffer);							//3 way
		//destStream.close();//closable interface garbage collection
		}
	}
		System.out.println("File has been transfered");
	}
	//charstream class
	public static void charStreamReadWrite(File fileFrom,File fileTo) throws FileNotFoundException,IOException{
		/*FileInputStream scrStream=new FileInputStream(fileFrom);
		FileOutputStream destStream=new FileOutputStream(fileTo);*/
		try(BufferedReader scrStream=new BufferedReader(new FileReader(fileFrom))){//objects of classses autoclosable type 
			//classes which implement autoclosable interface
			//try with resource
			try(BufferedWriter destStream=new BufferedWriter(new FileWriter(fileTo))){
		String data="";
			while((data=scrStream.readLine())!=null)
				destStream.write(data);
		}
	}
		System.out.println("File has been transfered");
	}
}
