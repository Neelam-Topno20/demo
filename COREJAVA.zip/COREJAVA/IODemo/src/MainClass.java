import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import com.cg.project.iodemo.IOClassesDemo;
import com.cg.project.iodemo.SerializationDemo;


public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		try{
			/*IOClassesDemo.fileClassDemo();*/
			
	/*		File fileFrom=new File("D:\\DataFile.txt");
			File fileTo=new File("D:\\159942_Neelam_Topno\\"+fileFrom.getName());
			IOClassesDemo.byteStreamReadWrite(fileFrom, fileTo);
			IOClassesDemo.charStreamReadWrite(fileFrom, fileTo);*/
			
			//File file =new File("D:\\DataFile.txt");
			/*SerializationDemo.doSerialization(file);
			SerializationDemo.doDeSerialization(file);*/
			
			//-------------------------------------------------------
			Properties projectProperties=new Properties();//map object
			projectProperties.load(new FileInputStream(new File(".//resources//projectProperties.properties")));
			String projectKey1=projectProperties.getProperty("projectKey1");
			String projectKey2=projectProperties.getProperty("projectKey2");
			System.out.println(projectKey1+" "+projectKey2);
		}
		catch(Exception e){ 
			e.printStackTrace();
		}
		/*catch (ClassNotFoundException e){
			e.printStackTrace();
		}
		*/
		
		
		
	}

}
