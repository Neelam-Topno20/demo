package com.cg.billing.beans;

public class Customer {

}
