package com.cg.payroll.daoservices;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import com.cg.payroll.beans.Associate;

public class AssociateDAOImpl implements AssociateDAO {
	
	private static HashMap<Integer,Associate> associates=new HashMap<>();
/*	private Associate []associates=new Associate[10];*/
	private static int ASSOCIATE_IDX=0;
	private static int  ASSOCIATE_ID_COUNTER=101;
	
   
	
	@Override
	public Associate save(Associate associate) {
		// TODO Auto-generated method stub
		associate.setAssociateID(ASSOCIATE_ID_COUNTER++);
		associates.put(associate.getAssociateID(),associate);
		return associate;
	}

	@Override
	public Associate findOne(int associateId) {
	/*	for(int i=0;i<associates.length;i++)
			if(associates[i]!=null&&associateId==associates[i].getAssociateID())
				return associates[i];*/
		return associates.get(associateId);
	}


	
	@Override
	public ArrayList<Associate> findAll() {
		// TODO Auto-generated method stub
		return new ArrayList<>(associates.values());
	}

}
