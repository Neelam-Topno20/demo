package com.cg.payroll.services;

import java.util.ArrayList;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.AssociateDetailNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;

public class PayrollServicesImpl implements PayrollServices{
	
	private AssociateDAO associateDao;
	
	
	public AssociateDAO getAssociateDao() {
		return associateDao;
	}

	public void setAssociateDao(AssociateDAO associateDao) {
		this.associateDao = associateDao;
	}

	public PayrollServicesImpl(AssociateDAO associateDao) {
		super();
		this.associateDao = associateDao;
	}

	@Override
	public int acceptAssociateDetails(String firstName, String lastName,
			String emailId, String department, String designation,
			String pancard, double yearlyInvestmentUnder80C,
			double basicSalary, double epf, double companyPf,
			long accountNumber, String bankName, String ifscCode)
			throws PayrollServicesDownException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double calculateNetSalary(int associateId)
			throws AssociateDetailNotFoundException,
			PayrollServicesDownException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Associate getAssociateDetails(int associateId)
			throws AssociateDetailNotFoundException,
			PayrollServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Associate> getAllAssociateDetails()
			throws PayrollServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	

}
