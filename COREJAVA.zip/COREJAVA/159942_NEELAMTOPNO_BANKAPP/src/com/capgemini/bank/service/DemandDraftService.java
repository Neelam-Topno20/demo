package com.capgemini.bank.service;

import java.sql.SQLException;
import java.time.LocalDate;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.exceptions.BankingServicesDownException;
import com.capgemini.bank.exceptions.DdAmountNotValidException;
import com.capgemini.bank.exceptions.DemandDraftDetailsNotFoundException;
import com.capgemini.bank.exceptions.PhoneNumberNotValidException;


public class DemandDraftService implements IDemandDraftService{
	
	DemandDraftDAO demandDraftDao=new DemandDraftDAO();
	
	public DemandDraftService(DemandDraftDAO demandDraftDao) {
		super();
		this.demandDraftDao = demandDraftDao;
	}

	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws DdAmountNotValidException, BankingServicesDownException,PhoneNumberNotValidException {
		try {
			//String name=demandDraft.getCustomerName();
			String phoneNumber=demandDraft.getPhoneNumber();
			//String inFavorOf=demandDraft.getInFavorOf();
			double ddAmount=demandDraft.getDdAmount();
			//String ddDescription=demandDraft.getDdDescription();
			
			if(phoneNumber.length()!=10)
				throw new PhoneNumberNotValidException();
			
			double commission;
			if(ddAmount<=5000)
				commission=10;
			else if(ddAmount<=10000)
				commission=41;
			else if(ddAmount<=100000)
				commission=51;
			else if (ddAmount<=500000)
				commission=306;
			else
				throw new DdAmountNotValidException();
			
			
			demandDraft.setDdCommission(commission);
			
			
			int transactionId=demandDraftDao.addDemandDraftDetails(demandDraft);
				return transactionId;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new BankingServicesDownException();
		}
	
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) throws BankingServicesDownException,DemandDraftDetailsNotFoundException{
		try {
			DemandDraft demandDraft=demandDraftDao.getDemandDraftDetails(transactionId);
			if(demandDraft==null) 
				throw new DemandDraftDetailsNotFoundException("demand draft not found");
			else
			return demandDraft;
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new BankingServicesDownException();
			
		}
	}

}
