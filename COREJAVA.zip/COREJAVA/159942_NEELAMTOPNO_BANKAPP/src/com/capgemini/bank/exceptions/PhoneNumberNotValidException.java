package com.capgemini.bank.exceptions;

public class PhoneNumberNotValidException extends Exception {

	public PhoneNumberNotValidException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PhoneNumberNotValidException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public PhoneNumberNotValidException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PhoneNumberNotValidException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PhoneNumberNotValidException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
