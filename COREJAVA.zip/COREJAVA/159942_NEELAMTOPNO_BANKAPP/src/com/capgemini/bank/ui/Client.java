package com.capgemini.bank.ui;

import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exceptions.BankingServicesDownException;
import com.capgemini.bank.exceptions.DdAmountNotValidException;
import com.capgemini.bank.exceptions.DemandDraftDetailsNotFoundException;
import com.capgemini.bank.exceptions.PhoneNumberNotValidException;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;
import com.capgemini.bank.util.ConnectionProvider;

public class Client {

	public static void main(String[] args) throws DdAmountNotValidException, BankingServicesDownException, PhoneNumberNotValidException, DemandDraftDetailsNotFoundException {
			
		if(ConnectionProvider.getDBConnection()!=null){
			System.out.println("connection set ");
		}
		else{
			System.out.println("connection not set");
		}
		
		IDemandDraftService idemandDraftService = new DemandDraftService();
		DemandDraft demandDraft=new DemandDraft();
		
		Scanner sc=new Scanner(System.in);
		String s="y";
		
		while(s.startsWith("Y") || s.startsWith("y")){
			System.out.println("1)Enter Demand Draft Details ");
			System.out.println("2)Show Demand Draft Details");
			System.out.println("3)Exit");
			System.out.println("Enter Your Choice");
			int choice= sc.nextInt();
			
			switch(choice){
				case 1:
			System.out.println("Enter the name of the customer");
			String s1=sc.next();
			demandDraft.setCustomerName(s1);
			System.out.println("Enter customer phone number");
			String l=sc.next();
			demandDraft.setPhoneNumber(l);
			System.out.println("In Favor of");
			String s2=sc.next();
			demandDraft.setInFavorOf(s2);
			System.out.println("Enter Demand Draft amount(in Rs)");
			double d=sc.nextDouble();
			demandDraft.setDdAmount(d);
			System.out.println("Enter Remarks:");
			String s3=sc.next();
			demandDraft.setDdDescription(s3);
			int transactionId=idemandDraftService.addDemandDraftDetails(demandDraft);
			System.out.println("Your Demand Draft request has been succesfully registered along with the "+transactionId);
			
			break;
				case 2:
				System.out.println("Enter the transaction id:");
				int tid=sc.nextInt();
				demandDraft=idemandDraftService.getDemandDraftDetails(tid);
				System.out.println(demandDraft.toString());
					break;
					
			case 3:
				break;
					
			default:
				System.out.println("Invalid Input");
				break;
			}
		System.out.println("Do you want to continue?(yes/no)");
		
		s=sc.next();
		
		}

	}

}
