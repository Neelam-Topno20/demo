package com.capgemini.bank.bean;



public class DemandDraft {
	private int transactionId;
	private String customerName;
	private String inFavorOf;
	private String phoneNumber;
	private String dateOfTransaction;
	private double ddAmount;
	private double ddCommission;
	private String ddDescription;
	public DemandDraft() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public DemandDraft(int transactionId, String customerName,
			String inFavorOf, String phoneNumber, String dateOfTransaction,
			double ddAmount, double ddCommission, String ddDescription) {
		super();
		this.transactionId = transactionId;
		this.customerName = customerName;
		this.inFavorOf = inFavorOf;
		this.phoneNumber = phoneNumber;
		this.dateOfTransaction = dateOfTransaction;
		this.ddAmount = ddAmount;
		this.ddCommission = ddCommission;
		this.ddDescription = ddDescription;
	}

	public DemandDraft(String customerName, String inFavorOf, String phoneNumber,
			double ddAmount, String ddDescription) {
		super();
		this.customerName = customerName;
		this.inFavorOf = inFavorOf;
		this.phoneNumber = phoneNumber;
		this.ddAmount = ddAmount;
		this.ddDescription = ddDescription;
	}

	public DemandDraft(String customerName, String inFavorOf, String phoneNumber,
			String dateOfTransaction, double ddAmount, double ddCommission,
			String ddDescription) {
		super();
		this.customerName = customerName;
		this.inFavorOf = inFavorOf;
		this.phoneNumber = phoneNumber;
		this.dateOfTransaction = dateOfTransaction;
		this.ddAmount = ddAmount;
		this.ddCommission = ddCommission;
		this.ddDescription = ddDescription;
	}

	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getInFavorOf() {
		return inFavorOf;
	}
	public void setInFavorOf(String inFavorOf) {
		this.inFavorOf = inFavorOf;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getDateOfTransaction() {
		return dateOfTransaction;
	}
	public void setDateOfTransaction(String dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}

	public double getDdAmount() {
		return ddAmount;
	}

	public void setDdAmount(double ddAmount) {
		this.ddAmount = ddAmount;
	}

	public double getDdCommission() {
		return ddCommission;
	}

	public void setDdCommission(double ddCommission) {
		this.ddCommission = ddCommission;
	}

	public String getDdDescription() {
		return ddDescription;
	}

	public void setDdDescription(String ddDescription) {
		this.ddDescription = ddDescription;
	}

	@Override
	public String toString() {
		return "DemandDraft [transactionId=" + transactionId
				+ ", customerName=" + customerName + ", inFavorOf=" + inFavorOf
				+ ", phoneNumber=" + phoneNumber + ", dateOfTransaction="
				+ dateOfTransaction + ", ddAmount=" + ddAmount
				+ ", ddCommission=" + ddCommission + ", ddDescription="
				+ ddDescription + "]";
	}
	
	}
	
	

