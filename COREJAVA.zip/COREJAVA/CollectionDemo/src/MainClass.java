import com.cg.project.beans.Associate;
import com.cg.project.collectiondemo.ListClassesDemo;


public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	/*	GenClass<String> obj=new GenClass<String>("","");
		obj.getRef1();
		
		GenClass<Integer> obj2=new GenClass<Integer>(100,200);//2 class files   obj!=obj2
		obj2.getRef1();
		
		callForPrint(obj);*/
		
		ListClassesDemo lcd=new ListClassesDemo();
		lcd.arrayListClassWork();
		
	}
	
	static void callForPrint(GenClass <String> obj3){
		
	}

}
