
public class GenClass<T> {
	/*Integer ref1,ref2;<E/T>

	public GenClass(Integer ref1, Integer ref2) {
		super();
		this.ref1 = ref1;
		this.ref2 = ref2;
	}
	*/
	T ref1,ref2;//type safety   generic type variables

	public GenClass(T ref1, T ref2) {
		super();
		this.ref1 = ref1;
		this.ref2 = ref2;
	}

	public T getRef1() {
		return ref1;
	}

	public void setRef1(T ref1) {
		this.ref1 = ref1;
	}

	public T getRef2() {
		return ref2;
	}

	public void setRef2(T ref2) {
		this.ref2 = ref2;
	}
	
}
