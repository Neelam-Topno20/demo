package com.cg.project.collectiondemo;

import java.util.HashMap;

import com.cg.project.beans.Associate;

public class MapClassesDemo {
	public static void hashMapClassWork(){
		HashMap<Integer,Associate> associates=new HashMap<>();
		
		associates.put(101, new Associate(101, 15000, "Satish"));
		associates.get(102).getName();
	}
}
