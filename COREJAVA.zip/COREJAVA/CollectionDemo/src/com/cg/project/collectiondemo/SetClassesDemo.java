package com.cg.project.collectiondemo;

import java.util.ArrayList;
import java.util.HashSet;

import com.cg.project.beans.Associate;

public class SetClassesDemo {
	public static void hashSetClassWork(){
		HashSet<Associate> associateSet=new HashSet<>();
		associateSet.add(new Associate());
		associateSet.add(new Associate());
		associateSet.add(new Associate());
	}	
}
