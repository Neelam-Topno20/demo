package com.cg.project.collectiondemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

import com.cg.project.beans.Associate;

public class ListClassesDemo {
	public static void arrayListClassWork(){
		ArrayList<String> strList=new ArrayList<>();
		strList.add("Satish");
		strList.add("Rajiv");
		strList.add("Aman");
		
		System.out.println(strList.contains("Aman"));//search
		
		/*ArrayList<Integer> intList=new ArrayList<Integer>();*/
		/*intList.contains(100);*/
		
		/*strList.indexOf("");*///search
		
		//sorting
		Collections.sort(strList);
		
	/*	for(int i=0;i<strList.size();i++)
			System.out.println(strList.get(i));*/
		
		for (String name : strList) 
			System.out.println(name);
		
		ArrayList<Associate> associateList=new ArrayList<>();
		associateList.add(new Associate(101,16000,"Satish"));
		associateList.add(new Associate(102,15600,"Aman"));
		associateList.add(new Associate(103,15900,"Rajiv"));
		
		Associate associateToBeSearch=new Associate(101,15000,"Satish");
		System.out.println(associateList.indexOf(associateToBeSearch));
		System.out.println(associateList.contains(associateToBeSearch));
		
		Collections.sort(associateList);
		
		Collections.sort(associateList,new AssociateComparator());
		for (Associate associate : associateList) {
			System.out.println(associate.toString());
			if(associate.getName().equals("Nilesh")&&associate.getAssociateId()==102);
		}
		
	}
	
	public static void linkedListClassWork(){
		LinkedList<String> strList=new LinkedList<>();
		strList.add("");
		
		
		strList.contains("");//search
		
		LinkedList<Integer> intList=new LinkedList<Integer>();
		intList.contains(100);
		
		strList.indexOf("");//search
		
		//sorting
		Collections.sort(strList);
	
		for(int i=0;i<strList.size();i++){
			System.out.println(strList.get(i));
			
		}
		for (String name : strList) 
			System.out.println(name);
		
	}
}
