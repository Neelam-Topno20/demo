package com.cg.project.beans;

public class Associate implements Comparable{
	private int AssociateId;
	private double salary;
	private String name;
	public Associate() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Associate(int associateId, double salary, String name) {
		super();
		AssociateId = associateId;
		this.salary = salary;
		this.name = name;
	}
	public int getAssociateId() {
		return AssociateId;
	}
	public void setAssociateId(int associateId) {
		AssociateId = associateId;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	/*@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + AssociateId;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		long temp;
		temp = Double.doubleToLongBits(salary);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}*/
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + AssociateId;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		long temp;
		temp = Double.doubleToLongBits(salary);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Associate other = (Associate) obj;
		if (AssociateId != other.AssociateId)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (Double.doubleToLongBits(salary) != Double
				.doubleToLongBits(other.salary))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "Associate [AssociateId=" + AssociateId + ", salary=" + salary
				+ ", name=" + name + "]";
	}
	@Override
	public int compareTo(Object arg0) {
		// TODO Auto-generated method stub
		return ((Associate)arg0).AssociateId-this.AssociateId;
	}

	}
	
	

