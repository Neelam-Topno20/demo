package com.zensar.project.lambdainterface;

public interface FunctionalInterface2 {
	public int add(int num1,int num2);
}
