package com.zensar.project.client;

import com.zensar.project.lambdainterface.FunctionalInterface1;
import com.zensar.project.lambdainterface.FunctionalInterface2;

public class MainClass {
	public static void main(String args[]){
		
		FunctionalInterface1 f1 = (firstName,lastName)->System.out.println("Hello "+firstName+" "+lastName);

		f1.greetUser("asdf","ghjf");
		
		FunctionalInterface2 f2=(num1,num2)->num1+num2;
		
		System.out.println(f2.add(56, 65));
		
		
	}

}
