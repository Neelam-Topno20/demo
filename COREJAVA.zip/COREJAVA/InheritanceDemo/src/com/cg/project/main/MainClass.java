package com.cg.project.main;

import com.cg.project.inheritance.CEmployee;
import com.cg.project.inheritance.Employee;
import com.cg.project.inheritance.PEmployee;

public class MainClass {

	public static void main(String[] args) {
		/*Employee emp=new Employee(101, "Satish", "Mahajan", 15000);
		emp.calculateTotalSalary();
		System.out.println(emp);*/
		
		Employee emp;
		
		emp=new PEmployee(102, "Nilesh", "Kumar", 15000);
		/*System.out.println(pemployee.getEmployeeId());*/
		

		emp.calculateTotalSalary();
		System.out.println(emp);
		
		emp=new  CEmployee(103, "Aakash", "Rao", 500);
		
		/*CEmployee cemp=new CEmployee(103, "Aakash", "Rao", 500);*/
		CEmployee cemp=(CEmployee)emp;
		cemp.signContract();
		cemp.calculateTotalSalary();
		System.out.println(cemp);
		
		
	}

}
