package com.cg.project.inheritance;

public final class CEmployee extends Employee {
	private int noOfHrs,variablePay;

	public CEmployee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CEmployee(int employeeId, String firstName, String lastName,
			int noOfHrs) {
		super(employeeId, firstName, lastName);
		// TODO Auto-generated constructor stub
		this.noOfHrs=noOfHrs;
	}

	public int getNoOfHrs() {
		return noOfHrs;
	}

	public void setNoOfHrs(int noOfHrs) {
		this.noOfHrs = noOfHrs;
	}

	public int getVariablePay() {
		return variablePay;
	}

	public void signContract(){
		System.out.println("Contract has been signed");
	}
	
	@Override
	public void calculateTotalSalary() {
		// TODO Auto-generated method stub
		/*super.CalculateTotalSalary();*/
		variablePay=noOfHrs*2000;
		this.setTotalSalary(variablePay);
	}

	
	@Override
	public String toString() {
		return super.toString()+",noOfHrs=" + noOfHrs + ", variablePay=" + variablePay;
	}
	
	
}
