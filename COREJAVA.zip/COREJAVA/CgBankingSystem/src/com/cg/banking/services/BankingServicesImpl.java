package com.cg.banking.services;

import java.sql.SQLException;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices{
	AccountDAOImpl accountDao=new AccountDAOImpl();
	@Override
	public long openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException,
			BankingServicesDownException {
		
		try {
			if(initBalance<500)
				throw new InvalidAmountException();
			if(!(accountType.equalsIgnoreCase("savings") || accountType.equalsIgnoreCase("current")))
				throw new InvalidAccountTypeException();
			
				Account account1=new Account(1234, accountType, "active", initBalance, 202366925);
				long accountNo=accountDao.accountCreate(account1);
				return accountNo;
				
		} catch (SQLException e) {
			
			e.printStackTrace();
			throw new BankingServicesDownException();
			
		}
		
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException,
			AccountBlockedException {
		try {
			accountDao.updateDeposit(accountNo,amount);
			return 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch()
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException {
		
		return 0;
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom,
			float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException {
		
		return false;
	}

	@Override
	public Account getAccountDetails(long accountNo)
			throws AccountNotFoundException, BankingServicesDownException {
		
		return null;
	}

	@Override
	public List<Account> getAllAccountDetails()
			throws BankingServicesDownException {

		return null;
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		
		return null;
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException,
			AccountBlockedException {
		
		return null;
	}

}
