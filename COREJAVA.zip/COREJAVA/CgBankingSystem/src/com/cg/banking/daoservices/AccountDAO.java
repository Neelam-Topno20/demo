package com.cg.banking.daoservices;

import java.sql.SQLException;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public interface AccountDAO {
long accountCreate(Account account)throws SQLException;
float updateDeposit(long accountNo,float amount)throws SQLException,AccountNotFoundException,AccountBlockedException;
float updateWithdraw(long accountNo, float amount, int pinNumber)throws SQLException,InvalidPinNumberException,InsufficientAmountException,AccountNotFoundException,AccountBlockedException;
boolean transferFund(long accountNoTo,long accountNoFrom,float transferAmount,int pinNumber)throws SQLException,InsufficientAmountException,AccountNotFoundException,InvalidPinNumberException,AccountBlockedException;
Account findOneAccount(long accountNo)throws SQLException,AccountNotFoundException;
List<Account> findAllAccount()throws SQLException;
List<Transaction> findAllTransactions(long accountNo) throws SQLException,AccountNotFoundException;
String reflectStatus(long accountNo)throws SQLException,AccountNotFoundException;
}
