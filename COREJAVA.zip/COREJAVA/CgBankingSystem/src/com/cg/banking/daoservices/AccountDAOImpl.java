package com.cg.banking.daoservices;

import java.sql.SQLException;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class AccountDAOImpl implements AccountDAO{

	@Override
	public long accountCreate(Account account)
			throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public float updateDeposit(long accountNo, float amount)
			throws SQLException, AccountNotFoundException,
			AccountBlockedException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public float updateWithdraw(long accountNo, float amount, int pinNumber)
			throws SQLException, InvalidPinNumberException,
			InsufficientAmountException, AccountNotFoundException,
			AccountBlockedException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean transferFund(long accountNoTo, long accountNoFrom,
			float transferAmount, int pinNumber) throws SQLException,
			InsufficientAmountException, AccountNotFoundException,
			InvalidPinNumberException, AccountBlockedException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Account findOneAccount(long accountNo) throws SQLException,
			AccountNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Account> findAllAccount() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> findAllTransactions(long accountNo)
			throws SQLException, AccountNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String reflectStatus(long accountNo) throws SQLException,
			AccountNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	
}
