package com.cg.payroll.client;

import com.cg.payroll.util.ConnectionProvider;

public class ConnectionTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if(ConnectionProvider.getDBConnection()!=null)
			System.out.println("Connection Secured");
		else
			System.out.println("not connected");
	}

}
