package com.cg.payroll.client;

import java.util.ArrayList;




import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.ConnectionProvider;

public class MainClass {

	public static void main(String[] args)throws PayrollServicesDownException, AssociateDetailNotFoundException {
		// TODO Auto-generated method stub

	/*	Associate associate1=new Associate(101, 15000, "Satish", "Mahajan", "YTP", "Sr.Con", "JDUU2664", "satish@gmail.com");
		Associate associate2=new Associate(102, 15000, "Rajesh", "Kumar", "YTP", "Sr.Con", "UDID7372", "rajesh@gmail.com");
		Associate associate3=new Associate(103, 15000, "Ashav", "Kumar", "YTP", "Sr.Con", "GHGH4543", "ashav@gmail.com");
		System.out.println("Firstname:="+associate1.getFirstName()+" Lastname:="+associate1.getLastName());

		BankDetails bankdetails1=new BankDetails(2026889575, "State Bank of India", "SBI0001882");
		BankDetails bankdetails2=new BankDetails(2028989575, "Bank of India", "BOI0000255");
		BankDetails bankdetails3=new BankDetails(2026878975, "HDFC", "HDFC0000055");

		Salary salary1=new Salary(17000, 8000, 5000, 2000, 1300, 2000, 2000, 1000, 42000, 40000);
		Salary salary2=new Salary(7000, 800, 500, 200, 130, 200, 200, 100, 4200, 4000);
		Salary salary3=new Salary(10000, 6000, 1000, 500, 1300, 2000, 2000, 1000, 42000, 40000);
		
		System.out.println(Associate.getASSOCIATE_COUNTER());*/
	/*	try{
        Associate associate=new Associate(101, 115000, "Satish", "Mahajan", "YTP", "Sr.Con", "BIOPT6767", "satish@gmail.com", new BankDetails(2023556," HDFC", "HDFC000012"), new Salary(17000, 2000, 2000, 500) );
			
			associate.getSalary().setConveyenceAllowance(20*associate.getSalary().getBasicSalary()/100);
			associate.getSalary().setOtherAllowance(20*associate.getSalary().getBasicSalary()/100);
			associate.getSalary().setHra(30*associate.getSalary().getBasicSalary()/100);
			associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary()+associate.getSalary().getHra()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getOtherAllowance());
			System.out.println(associate.getSalary().getGrossSalary());
			throw new AssociateDetailNotFoundException();
		}
		catch(AssociateDetailNotFoundException e){
			e.printStackTrace();
			
		}*/
	/*	PayrollServices payrollservices=new PayrollServicesImpl();
		int associateID=payrollservices.acceptAssociateDetails("Neelam", "Topno", "neelam@gmail.com", "YTP", "Sr.analyst", "GSHDA2345F", 20000, 17300, 0, 0, 5336355, "ICICI", "ICIC0000985");
		Associate associate = payrollservices.getAssociateDetails(associateID);
		payrollservices.calculateNetSalary(associateID);
		
		associateID=payrollservices.acceptAssociateDetails("Ashav", "Kumar", "ashav@gmail.com", "YTP", "Sr.analyst", "ASDJH4654D", 20000, 17300, 0, 0, 5336355, "ICICI", "ICIC0000985");
		 associate = payrollservices.getAssociateDetails(associateID);
		payrollservices.calculateNetSalary(associateID);
		
		associateID=payrollservices.acceptAssociateDetails("Keshav", "Kumar", "keshav@gmail.com", "YTP", "Sr.analyst", "JKLHG4568R", 20000, 17300, 0, 0, 5336355, "ICICI", "ICIC0000985");
		 associate = payrollservices.getAssociateDetails(associateID);
		payrollservices.calculateNetSalary(associateID);
		
		System.out.println(associate.toString());
		
		ArrayList<Associate> associateList=payrollservices.getAllAssociateDetails();
		for (Associate associate2 : associateList) 
			System.out.println(associate2.toString());*/
		
			PayrollServices payrollservices=new PayrollServicesImpl();
			int associateID=payrollservices.acceptAssociateDetails("Neelam", "Topno", "neelam@gmail.com", "YTP", "Sr.analyst", "GSHDA2345F", 20000, 17300, 2000, 2000, 5336355, "ICICI", "ICIC0000985");
			Associate associate = payrollservices.getAssociateDetails(associateID);
			//System.out.println(associate);
			payrollservices.calculateNetSalary(associateID);
			
			ArrayList<Associate> associateList=payrollservices.getAllAssociateDetails();
			for (Associate associate2 : associateList) 
				System.out.println(associate2.toString());
		
		
	}
	

}
