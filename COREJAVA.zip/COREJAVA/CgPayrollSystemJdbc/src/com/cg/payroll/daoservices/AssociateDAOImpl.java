package com.cg.payroll.daoservices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.util.ConnectionProvider;

	public class AssociateDAOImpl implements AssociateDAO {
	private Connection conn=ConnectionProvider.getDBConnection();
	
/*	private static HashMap<Integer,Associate> associates=new HashMap<>();
	private Associate []associates=new Associate[10];
	private static int ASSOCIATE_IDX=0;
	private static int  ASSOCIATE_ID_COUNTER=101;*/
	
   
	
	
	@Override
	public Associate save(Associate associate) throws SQLException
	{
		
		try{
			conn.setAutoCommit(false);
			PreparedStatement pstmt=conn.prepareStatement("insert into Associate(yearlyInvestmentUnder80C, firstName, lastName, department,designation,pancard,emailId) values(?,?,?,?,?,?,?)");//sequence.naextval 1st argument
			pstmt.setDouble(1, associate.getYearlyInvestmentUnder80C());
			pstmt.setString(2, associate.getFirstName());
			pstmt.setString(3, associate.getLastName());
			pstmt.setString(4, associate.getDepartment());
			pstmt.setString(5, associate.getDesignation());
			pstmt.setString(6, associate.getPancard());
			pstmt.setString(7, associate.getEmailId());
			pstmt.executeUpdate();
			
			PreparedStatement pstmt2=conn.prepareStatement("select max(associateid) from Associate");
			ResultSet rs=pstmt2.executeQuery();
			rs.next();//always open
			int associateId=rs.getInt(1);
			
			PreparedStatement pstmt3=conn.prepareStatement("insert into BankDetails values(?,?,?,?)");
			pstmt3.setInt(4, associateId);
			pstmt3.setLong(1, associate.getBankdetails().getAccountNumber());
			pstmt3.setString(2, associate.getBankdetails().getBankName());
			pstmt3.setString(3, associate.getBankdetails().getIfscCode());
			pstmt3.executeUpdate();
			
			PreparedStatement pstmt4=conn.prepareStatement("insert into Salary(associateId,basicSalary,epf,companyPf) values(?,?,?,?)");
			pstmt4.setInt(1, associateId);
			pstmt4.setDouble(2, associate.getSalary().getBasicSalary());
			pstmt4.setDouble(3, associate.getSalary().getEpf());
			pstmt4.setDouble(4, associate.getSalary().getCompanyPf());
			pstmt4.executeUpdate();
			
			conn.commit();
			associate.setAssociateID(associateId);
			return associate;
		}
		catch(SQLException e){
			e.printStackTrace();
			conn.rollback();
			throw e;
		}
		finally{
			conn.setAutoCommit(true);
		}
		
	}

	@Override
	public Associate findOne(int associateId) throws SQLException {
		PreparedStatement pstmt1=conn.prepareStatement("Select * from Associate where associateId="+associateId);
		ResultSet associateRS=pstmt1.executeQuery();
		if(associateRS.next()){
			String firstName=associateRS.getString("firstName");
			String lastName=associateRS.getString("lastName");
			String department=associateRS.getString("department");
			Double yearlyInvestmentUnder80C=associateRS.getDouble("yearlyInvestmentUnder80C");
			String designation=associateRS.getString("designation");
			String pancard=associateRS.getString("pancard");
			String emailId=associateRS.getString("emailId");
			Associate associate=new Associate(associateId, yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, null, null);
			
			PreparedStatement pstmt2=conn.prepareStatement("Select * from BankDetails where associateId="+associateId);
			ResultSet bankdetailsRS=pstmt2.executeQuery();
			bankdetailsRS.next();
			long accountNumber=bankdetailsRS.getLong("accountNumber");
			String bankName=bankdetailsRS.getString("bankName");
			String ifscCode=bankdetailsRS.getString("ifscCode");
			associate.setBankdetails(new BankDetails(accountNumber,bankName,ifscCode));
		
			PreparedStatement pstmt3=conn.prepareStatement("select * from Salary where associateId="+associateId);
			ResultSet salaryRS=pstmt3.executeQuery();
			
			salaryRS.next();
		
			double basicSalary=salaryRS.getDouble("basicSalary");
			double hra=salaryRS.getDouble("hra");
			double conveyanceAllowance=salaryRS.getDouble("conveyanceAllowance");
			double otherAllowance=salaryRS.getDouble("otherAllowance");
			double personalAllowance=salaryRS.getDouble("personalAllowance");
			double monthlyTax=salaryRS.getDouble("monthlyTax");
			double epf=salaryRS.getDouble("epf");
			double companyPf=salaryRS.getDouble("companyPf");
			double gratuity=salaryRS.getDouble("gratuity");
			double grossSalary=salaryRS.getDouble("grossSalary");
			double netSalary=salaryRS.getDouble("netSalary");
			
			associate.setSalary(new Salary(basicSalary, hra, conveyanceAllowance, otherAllowance, personalAllowance, monthlyTax, epf, companyPf, gratuity, grossSalary, netSalary));
			//associate.setSalary(new Salary(salaryRS.getDouble("basicSalary"),salaryRS.getDouble("hra"),salaryRS.getDouble("conveyanceAllowance"),salaryRS.getDouble("otherAllowance"),salaryRS.getDouble("personalAllowance"),salaryRS.getDouble("monthlyTax"),salaryRS.getDouble("epf"),salaryRS.getDouble("companyPf"),salaryRS.getDouble("gratuity"),salaryRS.getDouble("grossSalary"),salaryRS.getDouble("netSalary")));
			/*double basicSalary=salaryRS.getDouble("basicSalary");
			double epf=salaryRS.getDouble("epf");
			double companyPf=salaryRS.getDouble("companyPf");*/
			//associate.setSalary(new Salary(basicSalary, hra, conveyenceAllowance, otherAllowance, personalAllowance, monthlyTax, epf, companyPf, gratuity, grossSalary, netSalary));
			
			return associate;
		}
			
		return null;
	}


	
	@Override
	public ArrayList<Associate> findAll() throws SQLException {
		PreparedStatement pstmt1=conn.prepareStatement("Select * from Associate ");
		ResultSet associateRS=pstmt1.executeQuery();
		
		ArrayList<Associate> associates=new ArrayList<>();
		while(associateRS.next()){
			int associateId=associateRS.getInt("associateId");
			String firstName=associateRS.getString("firstName");
			String lastName=associateRS.getString("lastName");
			String department=associateRS.getString("department");
			Double yearlyInvestmentUnder80C=associateRS.getDouble("yearlyInvestmentUnder80C");
			String designation=associateRS.getString("designation");
			String pancard=associateRS.getString("pancard");
			String emailId=associateRS.getString("emailId");
			Associate associate=new Associate(associateId, yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, null, null);
			
			PreparedStatement pstmt2=conn.prepareStatement("Select * from BankDetails where associateId="+associateId);
			ResultSet bankdetailsRS=pstmt2.executeQuery();
			bankdetailsRS.next();
			long accountNumber=bankdetailsRS.getLong("accountNumber");
			String bankName=bankdetailsRS.getString("bankName");
			String ifscCode=bankdetailsRS.getString("ifscCode");
			associate.setBankdetails(new BankDetails(accountNumber,bankName,ifscCode));
		
			PreparedStatement pstmt3=conn.prepareStatement("select * from Salary where associateId="+associateId);
			ResultSet salaryRS=pstmt3.executeQuery();
			
			salaryRS.next();
		
			double basicSalary=salaryRS.getDouble("basicSalary");
			double hra=salaryRS.getDouble("hra");
			double conveyanceAllowance=salaryRS.getDouble("conveyanceAllowance");
			double otherAllowance=salaryRS.getDouble("otherAllowance");
			double personalAllowance=salaryRS.getDouble("personalAllowance");
			double monthlyTax=salaryRS.getDouble("monthlyTax");
			double epf=salaryRS.getDouble("epf");
			double companyPf=salaryRS.getDouble("companyPf");
			double gratuity=salaryRS.getDouble("gratuity");
			double grossSalary=salaryRS.getDouble("grossSalary");
			double netSalary=salaryRS.getDouble("netSalary");
			
			associate.setSalary(new Salary(basicSalary, hra, conveyanceAllowance, otherAllowance, personalAllowance, monthlyTax, epf, companyPf, gratuity, grossSalary, netSalary));
			associates.add(associate);	
		}
		
		return associates;
	}

	@Override
	public boolean update(Associate associate) {
		
		try {
			PreparedStatement pstmt1=conn.prepareStatement("UPDATE Salary SET hra= "+associate.getSalary().getHra()+",conveyanceAllowance="+associate.getSalary().getConveyenceAllowance()+",otherAllowance="+associate.getSalary().getOtherAllowance()+",personalAllowance="+associate.getSalary().getPersonalAllowance()+",gratuity="+associate.getSalary().getGratuity()+",grossSalary="+associate.getSalary().getGrossSalary()+",monthlyTax="+associate.getSalary().getMonthlyTax()+",netSalary="+associate.getSalary().getNetSalary()+" WHERE associateId="+associate.getAssociateID());
			/*pstmt1.setDouble(1, associate.getSalary().getHra());
			pstmt1.setDouble(2, associate.getSalary().getConveyenceAllowance());
			pstmt1.setDouble(3, associate.getSalary().getOtherAllowance());
			pstmt1.setDouble(4, associate.getSalary().getPersonalAllowance());
			pstmt1.setDouble(5, associate.getSalary().getGratuity());
			pstmt1.setDouble(6, associate.getSalary().getGrossSalary());
			pstmt1.setDouble(7, associate.getSalary().getMonthlyTax());
			pstmt1.setDouble(8, associate.getSalary().getNetSalary());*/
			pstmt1.executeQuery();
			
			
			
			PreparedStatement pstmt2=conn.prepareStatement("UPDATE Associate SET yearlyInvestmentUnder80C=? WHERE associateId="+associate.getAssociateID());
			pstmt2.setDouble(1, associate.getYearlyInvestmentUnder80C());
			pstmt2.executeQuery();
			
			return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
