package com.cg.payroll.services;

import java.util.ArrayList;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.AssociateDetailNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;

public class PayrollServicesImpl implements PayrollServices{

	AssociateDAO associateDAO=new AssociateDAOImpl();
		@Override
		public int acceptAssociateDetails(String firstName, String lastName,String emailId, String department, String designation,String pancard,
				double yearlyInvestmentUnder80C, double basicSalary, double epf, double companyPf,
				long accountNumber, String bankName, String ifscCode)throws PayrollServicesDownException {
			// TODO Auto-generated method stub
			Associate associate=new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId,  new BankDetails(accountNumber, bankName, ifscCode), new Salary(basicSalary, epf, companyPf));
			associate=associateDAO.save(associate);
			return associate.getAssociateID();
		
		}
		
	/*@Override
	public int acceptAssociateDetails(String firstName, String lastName,
			String emailId, String department, String designation,
			String pancard, double yearlyInvestmentUnder80C,double basicSalary,
			double epf, double companyPf, long accountNumber, String bankName,
			String ifscCode) throws PayrollServicesDownException {
		// TODO Auto-generated method stub
		Associate associate=new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId,  new BankDetails(accountNumber, bankName, ifscCode), new Salary(basicSalary, epf, companyPf));
		associate=associateDAO.save(associate);
		return associate.getAssociateID();
	}*/

	@Override
	public double calculateNetSalary(int associateId)
			throws AssociateDetailNotFoundException,
			PayrollServicesDownException {
		// TODO Auto-generated method stub
		Associate associate =getAssociateDetails(associateId);
		if(associate==null) throw new AssociateDetailNotFoundException("Associate Details Not Found");
		
		//tax calculation code
	double basicSalary= associate.getSalary().getBasicSalary();
		
		double hra=50*basicSalary/100;
		associate.getSalary().setHra(hra);
		
		double conveyenceAllowance=25*basicSalary/100;
		associate.getSalary().setConveyenceAllowance(conveyenceAllowance);
		
		double otherAllowance=25*basicSalary/100;
		associate.getSalary().setOtherAllowance(otherAllowance);
		
		double personalAllowance=40*basicSalary/100;
		associate.getSalary().setPersonalAllowance(personalAllowance);
		
		double epf=12*basicSalary/100;
		associate.getSalary().setEpf(epf);
		
		double companyPf = 12*basicSalary/100;
		associate.getSalary().setCompanyPf(companyPf);
		
		double  gratuity=481*basicSalary/10000;
		associate.getSalary().setGratuity(gratuity);
		
		double  grossSalary=basicSalary+conveyenceAllowance+otherAllowance+personalAllowance+epf;
		associate.getSalary().setGrossSalary(grossSalary);
		double yearlyInvestmentUnder80C = epf+associate.getYearlyInvestmentUnder80C();
		if(yearlyInvestmentUnder80C>150000)
			yearlyInvestmentUnder80C=150000;
		associate.setYearlyInvestmentUnder80C(yearlyInvestmentUnder80C);
		
		double taxableIncome = 12*(grossSalary-epf)-yearlyInvestmentUnder80C;
		double yearlyTax=0;
		if(taxableIncome<=250000)
			yearlyTax=0;
		else if(taxableIncome>250000 && taxableIncome<=500000)
			yearlyTax=5*(taxableIncome-250000)/100;
		else if(taxableIncome>500000 && taxableIncome<=1000000)
			yearlyTax=12500+20*(taxableIncome-500000);
		else
			yearlyTax=112500+30*(taxableIncome-1000000);
		double monthlyTax=yearlyTax/12;
		associate.getSalary().setMonthlyTax(monthlyTax);
		
		double netSalary=grossSalary-epf-monthlyTax;
		associate.getSalary().setNetSalary(netSalary);
		
		return netSalary;
		
	
	}

	@Override
	public Associate  getAssociateDetails(int associateId)
			throws AssociateDetailNotFoundException,
			PayrollServicesDownException {
		// TODO Auto-generated method stub
		Associate associate=associateDAO.findOne(associateId);
		
		if(associate==null)throw new AssociateDetailNotFoundException("Associate Details Not Found");
		else
		return associate;
	}

	@Override
	public  ArrayList<Associate> getAllAssociateDetails()
			throws PayrollServicesDownException {
		
		return associateDAO.findAll();
	}

}
