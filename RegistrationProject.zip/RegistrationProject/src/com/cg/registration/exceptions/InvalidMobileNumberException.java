package com.cg.registration.exceptions;

public class InvalidMobileNumberException extends Exception {

}
