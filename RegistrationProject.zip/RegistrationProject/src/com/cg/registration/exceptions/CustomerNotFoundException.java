package com.cg.registration.exceptions;

public class CustomerNotFoundException extends Exception{

}
