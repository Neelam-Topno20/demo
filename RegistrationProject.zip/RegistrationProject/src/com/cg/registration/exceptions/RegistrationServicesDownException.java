package com.cg.registration.exceptions;

public class RegistrationServicesDownException extends Exception{

}
