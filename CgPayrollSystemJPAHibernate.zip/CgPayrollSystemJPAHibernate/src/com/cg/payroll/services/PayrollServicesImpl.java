package com.cg.payroll.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.AssociateDetailNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;


public class PayrollServicesImpl implements PayrollServices{

	private AssociateDAO dao=new AssociateDAOImpl();
	
	
	public PayrollServicesImpl(AssociateDAO associateDAO) {
		super();
		this.dao = associateDAO;
	}

	public PayrollServicesImpl() {
		
	}

	//private static final Logger logger=Logger.getLogger(PayrollServicesImpl.class);
	//private static final Logger logger=Logger.getLogger(PayrollServicesImpl.class);
		@Override
		public int acceptAssociateDetails(String firstName, String lastName,String emailId, String department, String designation,String pancard,
				double yearlyInvestmentUnder80C, double basicSalary, double epf, double companyPf,
				long accountNumber, String bankName, String ifscCode)throws PayrollServicesDownException {
			
			
			try {
				Associate associate=new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId,  new BankDetails(accountNumber, bankName, ifscCode), new Salary(basicSalary, epf, companyPf));
				associate=dao.save(associate);
				return associate.getAssociateID();
				
			} catch (Exception e) {
				e.getMessage();
				//logger.error(e.getMessage()+" "+e.getCause());
				throw new PayrollServicesDownException("Services down please try again",e);//wrapper exception 
			}
			
		
		}
		
	
		/*private void updateValue(String col,double val,int associateid) throws PayrollServicesDownException {
			try {
				associate=dao.save(associate);
			} 
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();logger.error(e.getMessage()+" "+e.getCause()+" "+e.getErrorCode());
				throw new PayrollServicesDownException("Services Down",e);
			}*/
			
		//}
	@Override
	public double calculateNetSalary(int associateId)
			throws AssociateDetailNotFoundException,
			PayrollServicesDownException {
		// TODO Auto-generated method stub
		Associate associate =getAssociateDetails(associateId);
		if(associate==null) throw new AssociateDetailNotFoundException("Associate Details Not Found");
		
		//tax calculation code
	double basicSalary= associate.getSalary().getBasicSalary();
		
		double hra=50*basicSalary/100;
		associate.getSalary().setHra(hra);
		//updateValue("hra",hra,associateId);
		
		double conveyenceAllowance=25*basicSalary/100;
		associate.getSalary().setConveyenceAllowance(conveyenceAllowance);
		//updateValue("conveyanceAllowance",conveyenceAllowance,associateId);
		
		double otherAllowance=25*basicSalary/100;
		associate.getSalary().setOtherAllowance(otherAllowance);
		
		double personalAllowance=40*basicSalary/100;
		associate.getSalary().setPersonalAllowance(personalAllowance);
		
		double epf=12*basicSalary/100;
		associate.getSalary().setEpf(epf);
		
		
		double companyPf = 12*basicSalary/100;
		associate.getSalary().setCompanyPf(companyPf);
		
		double  gratuity=481*basicSalary/10000;
		associate.getSalary().setGratuity(gratuity);
		
		double  grossSalary=basicSalary+conveyenceAllowance+otherAllowance+personalAllowance+epf;
		associate.getSalary().setGrossSalary(grossSalary);
		
		double yearlyInvestmentUnder80C = epf+associate.getYearlyInvestmentUnder80C();
		if(yearlyInvestmentUnder80C>150000)
			yearlyInvestmentUnder80C=150000;
		associate.setYearlyInvestmentUnder80C(yearlyInvestmentUnder80C);
		
		double taxableIncome = 12*(grossSalary-epf)-yearlyInvestmentUnder80C;
		double yearlyTax=0;
		if(taxableIncome<=250000)
			yearlyTax=0;
		else if(taxableIncome>250000 && taxableIncome<=500000)
			yearlyTax=5*(taxableIncome-250000)/100;
		else if(taxableIncome>500000 && taxableIncome<=1000000)
			yearlyTax=12500+20*(taxableIncome-500000);
		else
			yearlyTax=112500+30*(taxableIncome-1000000);
		double monthlyTax=yearlyTax/12;
		associate.getSalary().setMonthlyTax(monthlyTax);
		
		double netSalary=grossSalary-epf-monthlyTax;
		associate.getSalary().setNetSalary(netSalary);
		
		if(dao.update(associate))
			System.out.println("associate updated ");
		else
			System.out.println("associate not updated");
		
		return netSalary;
	}

	@Override
	public Associate  getAssociateDetails(int associateId) throws AssociateDetailNotFoundException,PayrollServicesDownException {
		Associate associate;
		try {
			associate = dao.findOne(associateId);
			if(associate==null)
				throw new AssociateDetailNotFoundException("Associate Details Not Found");
			else
				return associate;
		} 
		catch (Exception e) {
			e.printStackTrace();
			//logger.error(e);
			throw new PayrollServicesDownException("Services down please try again",e);
		}
		
	
	}

	@Override
	public  ArrayList<Associate> getAllAssociateDetails()
			throws PayrollServicesDownException {
		
		try {
			return dao.findAll();
		} catch (Exception e) {
			e.printStackTrace();
			//logger.error(e);
			throw new PayrollServicesDownException("Services down please try again",e);
		}
		
	}

}
