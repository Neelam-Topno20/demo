package com.cg.payroll.daoservices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.util.EntityManagerFactoryProvider;


	public class AssociateDAOImpl implements AssociateDAO {

		EntityManagerFactory factory = EntityManagerFactoryProvider.getEntityManagerFactory();
		@Override
		public Associate save(Associate associate) {
			EntityManager entityManager = factory.createEntityManager();
			entityManager.getTransaction().begin();
			entityManager.persist(associate);
			entityManager.getTransaction().commit();
			entityManager.close();
			return associate;
		}

		@Override
		public Associate findOne(int associateId) {
			EntityManager entityManager = factory.createEntityManager();
			return entityManager.find(Associate.class, associateId);
		}

		@Override
		public ArrayList<Associate> findAll() {
			EntityManager entityManager = factory.createEntityManager();
			Query query = entityManager.createQuery("from Associate ");
			ArrayList<Associate> list=(ArrayList<Associate>) query.getResultList();//returns list type
			return list;
		}

		@Override
		public boolean update(Associate associate) {
			EntityManager entityManager = factory.createEntityManager();
			entityManager.getTransaction().begin();
			entityManager.persist(associate);
			entityManager.getTransaction().commit();
			entityManager.close();
			return true;
		}

}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
