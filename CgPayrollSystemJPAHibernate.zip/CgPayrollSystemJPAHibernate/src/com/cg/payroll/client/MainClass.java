package com.cg.payroll.client;

import java.util.ArrayList;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass {

	public static void main(String[] args)throws PayrollServicesDownException, AssociateDetailNotFoundException {

			PayrollServices payrollservices=new PayrollServicesImpl();
			int associateID=payrollservices.acceptAssociateDetails("Neelam", "Topno", "neelam@gmail.com", "YTP", "Sr.analyst", "GSHDA2345F", 20000, 17300, 2000, 2000, 5336355, "ICICI", "ICIC0000985");
			System.out.println(associateID);
			Associate associate = payrollservices.getAssociateDetails(associateID);
			System.out.println(associate.toString());
			payrollservices.calculateNetSalary(associateID);
			
			
			ArrayList<Associate> associateList=payrollservices.getAllAssociateDetails();
			for (Associate associate2 : associateList) 
				System.out.println(associate2.toString());
		
		
	}
	

}
