package com.cg.project.beans;

import javax.persistence.Entity;
import javax.persistence.OneToOne;

@Entity
public class Car {
private int carCode;
private String modelName;
private int price;
@OneToOne
private Customer customer ;
public Car(){}


}
