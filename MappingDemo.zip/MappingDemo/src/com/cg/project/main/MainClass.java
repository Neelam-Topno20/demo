package com.cg.project.main;

import javax.persistence.EntityManagerFactory;

import com.cg.project.util.EntityManagerFactoryProvider;

public class MainClass {
	
	EntityManagerFactory factory = EntityManagerFactoryProvider.getEntityManagerFactory();
	public static void main(String[] args) {
		

	}

}
