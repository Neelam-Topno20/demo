package com.cg.mobilepurchase.exceptions;

public class NoMobileInThisPriceRangeException extends Exception {

}
