package com.cg.mobilepurchase.exceptions;

public class InvalidCustomerNameException extends Exception {

}
