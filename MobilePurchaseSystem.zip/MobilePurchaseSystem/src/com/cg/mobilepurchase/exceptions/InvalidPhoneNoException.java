package com.cg.mobilepurchase.exceptions;

public class InvalidPhoneNoException extends Exception {

}
