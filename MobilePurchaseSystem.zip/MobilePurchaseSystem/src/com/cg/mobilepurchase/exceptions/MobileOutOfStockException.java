package com.cg.mobilepurchase.exceptions;

public class MobileOutOfStockException extends Exception {

}
