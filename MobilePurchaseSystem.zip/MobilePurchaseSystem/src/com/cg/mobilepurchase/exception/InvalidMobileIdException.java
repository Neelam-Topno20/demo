package com.cg.mobilepurchase.exception;

public class InvalidMobileIdException extends Exception {

}
