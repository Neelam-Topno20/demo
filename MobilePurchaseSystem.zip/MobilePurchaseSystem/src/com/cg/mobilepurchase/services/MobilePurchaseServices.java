package com.cg.mobilepurchase.services;

import java.util.ArrayList;

import com.cg.mobilepurchase.beans.Mobile;
import com.cg.mobilepurchase.beans.PurchaseDetails;
import com.cg.mobilepurchase.exception.InvalidMobileIdException;
import com.cg.mobilepurchase.exceptions.InvalidCustomerNameException;
import com.cg.mobilepurchase.exceptions.InvalidMailIdException;
import com.cg.mobilepurchase.exceptions.InvalidPhoneNoException;
import com.cg.mobilepurchase.exceptions.MobileOutOfStockException;
import com.cg.mobilepurchase.exceptions.NoMobileInThisPriceRangeException;

public interface MobilePurchaseServices {
int acceptPurchaseDetails(PurchaseDetails purchaseDetails) throws InvalidCustomerNameException, InvalidMailIdException, InvalidPhoneNoException, InvalidMobileIdException, MobileOutOfStockException;
ArrayList<Mobile> getAllMobileDetails();
boolean deleteMobileDetails(int MobileId);
ArrayList<Mobile> getMobileBetweenPrice(double begPrice,double endPrice) throws NoMobileInThisPriceRangeException;
}
