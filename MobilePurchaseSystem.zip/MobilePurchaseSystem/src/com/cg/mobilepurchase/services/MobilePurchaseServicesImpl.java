package com.cg.mobilepurchase.services;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.cg.mobilepurchase.beans.Mobile;
import com.cg.mobilepurchase.beans.PurchaseDetails;
import com.cg.mobilepurchase.dao.MobilePurchaseDAO;
import com.cg.mobilepurchase.dao.MobilePurchaseDAOImpl;
import com.cg.mobilepurchase.exception.InvalidMobileIdException;
import com.cg.mobilepurchase.exceptions.InvalidCustomerNameException;
import com.cg.mobilepurchase.exceptions.InvalidMailIdException;
import com.cg.mobilepurchase.exceptions.InvalidPhoneNoException;
import com.cg.mobilepurchase.exceptions.MobileOutOfStockException;
import com.cg.mobilepurchase.exceptions.NoMobileInThisPriceRangeException;

public class MobilePurchaseServicesImpl implements MobilePurchaseServices{
	
	MobilePurchaseDAO mobilePurchaseDao=new MobilePurchaseDAOImpl();
	@Override
	public int acceptPurchaseDetails(PurchaseDetails purchaseDetails) throws InvalidCustomerNameException, InvalidMailIdException, InvalidPhoneNoException, InvalidMobileIdException, MobileOutOfStockException {
		try {
			String cName=purchaseDetails.getcName();
			if(!Pattern.matches("[A-Z][a-zA-Z]{0,19}", cName))
				throw new InvalidCustomerNameException();
			String mailId=purchaseDetails.getMailId();
			if(!Pattern.matches("[a-zA-Z][a-zA-Z0-9-_.]{1,}[@][a-zA-Z]{5,}[.][a-zA-Z]{3,}", mailId))
				throw new InvalidMailIdException();
			String phoneNo=purchaseDetails.getPhoneNo();
			if(!Pattern.matches("[1-9][0-9]{9}", phoneNo))
				throw new InvalidPhoneNoException();
			int mobileId=purchaseDetails.getMobile().getMobileId();
			if(!(mobileId>=1000 && mobileId<=9999))
				throw new InvalidMobileIdException();
			
			purchaseDetails=mobilePurchaseDao.save(purchaseDetails);
			return purchaseDetails.getPurchaseId();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
	@Override
	public ArrayList<Mobile> getAllMobileDetails() {
		
		try {
			return mobilePurchaseDao.findAll();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public boolean deleteMobileDetails(int MobileId) {
		return mobilePurchaseDao.deleteOne(MobileId);
	}
	@Override
	public ArrayList<Mobile> getMobileBetweenPrice(double begPrice,
			double endPrice) throws NoMobileInThisPriceRangeException {
		List<Mobile> mobileList=mobilePurchaseDao.findBetweenRange(begPrice, endPrice);
		if(mobileList==null)
			throw new NoMobileInThisPriceRangeException();
		else
		return  (ArrayList<Mobile>) mobileList;
	}

}
