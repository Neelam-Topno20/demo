package com.cg.mobilepurchase.main;

import java.sql.Connection;
import java.util.List;
import java.util.Scanner;

import com.cg.mobilepurchase.beans.Mobile;
import com.cg.mobilepurchase.beans.PurchaseDetails;
import com.cg.mobilepurchase.exception.InvalidMobileIdException;
import com.cg.mobilepurchase.exceptions.InvalidCustomerNameException;
import com.cg.mobilepurchase.exceptions.InvalidMailIdException;
import com.cg.mobilepurchase.exceptions.InvalidPhoneNoException;
import com.cg.mobilepurchase.exceptions.MobileOutOfStockException;
import com.cg.mobilepurchase.exceptions.NoMobileInThisPriceRangeException;
import com.cg.mobilepurchase.services.MobilePurchaseServices;
import com.cg.mobilepurchase.services.MobilePurchaseServicesImpl;
import com.cg.payroll.util.ConnectionProvider;


public class MainClass {

	public static void main(String[] args) throws InvalidCustomerNameException, InvalidMailIdException, InvalidPhoneNoException, InvalidMobileIdException, MobileOutOfStockException, NoMobileInThisPriceRangeException {
		Connection conn=ConnectionProvider.getDBConnection();
		if(conn!=null)
			System.out.println("connected");
		else
			System.out.println("not connected");
		
		MobilePurchaseServices mobilePurchaseServices=new MobilePurchaseServicesImpl();
		Scanner sc=new Scanner(System.in);
		PurchaseDetails purchaseDetails=new PurchaseDetails();
		String s="yes";
	/*	
		PurchaseDetails purchaseDetails=new PurchaseDetails("Keshav", "keshav@gmail.com", "8083969915", new Mobile(1005));
		int purchaseId=mobilePurchaseServices.acceptPurchaseDetails(purchaseDetails);
		System.out.println("Reg ID: "+purchaseId);
		System.out.println("Congrats!! mobile is purchased");
		
		List<Mobile> mobileList=mobilePurchaseServices.getAllMobileDetails();
		for (Mobile mobile : mobileList) {
			System.out.println(mobile.toString());
		}
		
		if(mobilePurchaseServices.deleteMobileDetails(1004))
			System.out.println("record deleted");
		List<Mobile> mobileList=mobilePurchaseServices.getMobileBetweenPrice(10000, 40000);
		for (Mobile mobile : mobileList) 
			System.out.println(mobile.toString());
		*/
		while(s.equalsIgnoreCase("yes")){
			System.out.println("1)Insert Purchase Details ");
			System.out.println("2)Print Mobile Details");
			System.out.println("3)Delete mobile details");
			System.out.println("4)Search Mobile based on Price Range");
			System.out.println("6)Exit");
			System.out.println("Enter Your Choice");
			int choice= sc.nextInt();
			
			switch(choice){
				case 1:
			System.out.println("Enter the name of the customer");
			String cName=sc.next();
			purchaseDetails.setcName(cName);
			System.out.println("Enter mailId");
			String mailId=sc.next();
			purchaseDetails.setMailId(mailId);
			System.out.println("enter phoneNumber");
			 String phoneNo=sc.next();
			 purchaseDetails.setPhoneNo(phoneNo);
			System.out.println("Enter 4 digit mobileId");
			int mobileId=sc.nextInt();
			purchaseDetails.setMobile(new Mobile(mobileId));
			
			int purchaseId=mobilePurchaseServices.acceptPurchaseDetails(purchaseDetails);
			System.out.println("Reg ID: "+purchaseId);
			System.out.println("Congrats!! mobile is purchased");
			
			
			
			break;
				case 2:
					List<Mobile> mobileList=mobilePurchaseServices.getAllMobileDetails();
				for (Mobile mobile : mobileList) {
					System.out.println(mobile.toString());
						}
					break;
					
			case 3:
				System.out.println("Enter mobile id");
				int mobileId2=sc.nextInt();
				if(mobilePurchaseServices.deleteMobileDetails(mobileId2))
			System.out.println("record deleted");
					break;
					
			case 4:
						double begPrice,endPrice;
						System.out.println("enter beginning price and end price ");
						begPrice=sc.nextDouble();
						endPrice=sc.nextDouble();
			List<Mobile> mobileList1=mobilePurchaseServices.getMobileBetweenPrice(begPrice, endPrice);
		for (Mobile mobile : mobileList1) 
			System.out.println(mobile.toString());
					break;
					
			default:
				System.out.println("Invalid Input");
				break;
			}
		System.out.println("Do you want to continue?(yes/no)");
		
		s=sc.next();
		
		}
	
	}

}
