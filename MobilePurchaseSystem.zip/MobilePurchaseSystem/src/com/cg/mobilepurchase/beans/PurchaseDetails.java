package com.cg.mobilepurchase.beans;

public class PurchaseDetails {
	
	private int purchaseId;
	private String cName,mailId,phoneNo,purchaseDate;
	Mobile mobile;
	public PurchaseDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public PurchaseDetails(String cName, String mailId, String phoneNo,
			 Mobile mobile) {
		super();
		this.cName = cName;
		this.mailId = mailId;
		this.phoneNo = phoneNo;
		this.mobile = mobile;
	}

	public int getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public Mobile getMobile() {
		return mobile;
	}
	public void setMobile(Mobile mobile) {
		this.mobile = mobile;
	}
	
	
}
