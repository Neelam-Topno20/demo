package com.cg.mobilepurchase.beans;

public class Mobile {
	
	private int mobileId;
	private String name,quantity;
	private double price;
	
	
	@Override
	public String toString() {
		return "Mobile [mobileId=" + mobileId + ", name=" + name
				+ ", quantity=" + quantity + ", price=" + price + "]";
	}
	public Mobile(int mobileId, String name, String quantity, double price) {
		super();
		this.mobileId = mobileId;
		this.name = name;
		this.quantity = quantity;
		this.price = price;
	}
	public Mobile(int mobileId) {
		super();
		this.mobileId = mobileId;
	}
	public Mobile() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
}
