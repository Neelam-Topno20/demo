package com.cg.mobilepurchase.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.mobilepurchase.beans.Mobile;
import com.cg.mobilepurchase.beans.PurchaseDetails;
import com.cg.mobilepurchase.exception.InvalidMobileIdException;
import com.cg.mobilepurchase.exceptions.MobileOutOfStockException;



public interface MobilePurchaseDAO {
	PurchaseDetails save(PurchaseDetails purchaseDetails)throws SQLException, MobileOutOfStockException, InvalidMobileIdException;
	/*Associate findOne(int associateId)throws SQLException;
	ArrayList<Associate> findAll()throws SQLException;
	boolean update(Associate associate);*/
	ArrayList<Mobile> findAll()throws SQLException;
	boolean deleteOne(int mobileId);
	ArrayList<Mobile> findBetweenRange(double begPrice,double endPrice);
}

