package com.cg.mobilepurchase.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.mobilepurchase.beans.Mobile;
import com.cg.mobilepurchase.beans.PurchaseDetails;
import com.cg.mobilepurchase.exception.InvalidMobileIdException;
import com.cg.mobilepurchase.exceptions.MobileOutOfStockException;
import com.cg.payroll.util.ConnectionProvider;

public class MobilePurchaseDAOImpl implements MobilePurchaseDAO{
	private Connection conn=ConnectionProvider.getDBConnection();
	@Override
	public PurchaseDetails save(PurchaseDetails purchaseDetails)
			throws  MobileOutOfStockException, InvalidMobileIdException {
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt1=conn.prepareStatement("SELECT quantity from MOBILES where mobileid= "+purchaseDetails.getMobile().getMobileId());
			ResultSet rs1=pstmt1.executeQuery();
			//rs1.next();
			//System.out.println(rs1.getInt(1));
			boolean flag=rs1.next();
			if(flag==false)
				throw new InvalidMobileIdException();
			String quantity=rs1.getString(1);
			if(quantity.equals("0"))
				throw new MobileOutOfStockException();
			
			
			PreparedStatement pstmt2=conn.prepareStatement("INSERT INTO purchasedetails(purchaseid ,\r\n" + 
					"cname ,\r\n" + 
					"mailid ,\r\n" + 
					"phoneno ,\r\n" + 
					"purchasedate ,\r\n" + 
					"mobileid)VALUES(purchaseid_seq.nextval,?,?,?,sysdate,?)");     
			pstmt2.setString(1,purchaseDetails.getcName());
			pstmt2.setString(2,purchaseDetails.getMailId());
			pstmt2.setString(3,purchaseDetails.getPhoneNo());
			pstmt2.setInt(4,purchaseDetails.getMobile().getMobileId());
			pstmt2.executeUpdate();
			
			PreparedStatement pstmt3=conn.prepareStatement("select max(purchaseid) from purchasedetails");
			ResultSet rs2=pstmt3.executeQuery();
			rs2.next();
			int purchaseId=rs2.getInt(1);
			purchaseDetails.setPurchaseId(purchaseId);
			PreparedStatement pstmt4=conn.prepareStatement("update mobiles set quantity="+(Integer.parseInt(quantity)-1)+"where mobileid="+purchaseDetails.getMobile().getMobileId());
			pstmt4.executeUpdate();
			conn.commit();
			
			return purchaseDetails;
		} catch (SQLException e) {
				try {
					conn.rollback();
					
				} catch (SQLException e1) {
				
					e1.printStackTrace();
				}
			e.printStackTrace();
		}
		return purchaseDetails;
		
	}
	@Override
	public ArrayList<Mobile> findAll() throws SQLException {
		PreparedStatement pstmt1=conn.prepareStatement("Select * from mobiles ");
		ResultSet rs1=pstmt1.executeQuery();
		
		ArrayList<Mobile> mobileList=new ArrayList<>();
		while(rs1.next()){
			
			int mobileId=rs1.getInt("mobileid");
			String name=rs1.getString("name");
			double price=rs1.getDouble("price");
			String quantity=rs1.getString("quantity");
			Mobile mobile=new Mobile(mobileId, name, quantity, price);
			mobileList.add(mobile);	
		}
		
		return mobileList;
	
	}
	@Override
	public boolean deleteOne(int mobileId) {
		try {
			PreparedStatement pstmt1=conn.prepareStatement("SELECT * from MOBILES where mobileid= "+mobileId);
			ResultSet rs1=pstmt1.executeQuery();
			boolean flag=rs1.next();
			if(flag==false)
				throw new InvalidMobileIdException();
			
			PreparedStatement pstmt2=conn.prepareStatement("DELETE from mobiles where mobileid="+mobileId);
			pstmt2.executeUpdate();
			return true;
		} catch (SQLException e) {
		
			e.printStackTrace();
		} catch (InvalidMobileIdException e) {
			
			e.printStackTrace();
		}
		return false;
	}
	@Override
	public ArrayList<Mobile> findBetweenRange(double begPrice, double endPrice) {
		
		try {
			PreparedStatement pstmt1=conn.prepareStatement("SELECT * from MOBILES where price between  "+begPrice+" and "+endPrice);
			ResultSet rs1=pstmt1.executeQuery();
			ArrayList<Mobile> mobileList=new ArrayList<>();
			while(rs1.next()){
				
				int mobileId=rs1.getInt("mobileid");
				String name=rs1.getString("name");
				double price=rs1.getDouble("price");
				String quantity=rs1.getString("quantity");
				Mobile mobile=new Mobile(mobileId, name, quantity, price);
				mobileList.add(mobile);	
			}
			
			return mobileList;
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
	}

}
